# global settings for the PostgreSQL database
username = 'postgres'
password = 'infint'
host = 'localhost'
port = '5432'
database = 'postgres'

data_dir = r'C:\Users\johan\Development\HPI\1_Semester\II\data'

mapping_cols = ['key', 'value']
